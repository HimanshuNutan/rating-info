INSERT INTO Metadatainfo
(docid, doctype, docsize)
VALUES('1','pdf','25Kb');

INSERT INTO Metadatainfo
(docid, doctype, docsize)
VALUES('2','jpg','196Kb');