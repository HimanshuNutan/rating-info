DROP TABLE IF EXISTS Metadatainfo;

CREATE TABLE Metadatainfo(
docid varchar(10),
doctype varchar(30),
docsize varchar(30));