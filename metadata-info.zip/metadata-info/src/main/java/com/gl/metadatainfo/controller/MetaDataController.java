package com.gl.metadatainfo.controller;

import com.gl.metadatainfo.model.MetaDataInfo;
import com.gl.metadatainfo.service.MetaDataService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/metainfo")
public class MetaDataController {

	private static final Logger logger = LoggerFactory.getLogger(MetaDataController.class);

	@Autowired
	private MetaDataService metadataService;

	@PostMapping(value = "/info")
	public void addMetadataInfo(@RequestBody MetaDataInfo metadataInfo)
	{try{
		logger.trace("add function called");
		metadataService.addMetadataInfo(metadataInfo);
	}catch (Exception e){
		logger.error("error while adddocument call "+e);
	}
	}

	@GetMapping(value = "/info/{docId}")
	public MetaDataInfo getMetadataInfo(@PathVariable("docId") String docId){
		MetaDataInfo metaInfo = null;
		try{
		metaInfo = metadataService.getMetadataInfo(docId);
		System.out.println("  in controller  "+metaInfo.getDocId());
	}catch (Exception e){
		logger.error("error while adddocument call "+e);
	}
		return metaInfo;
	}

	@DeleteMapping(value = "/info/{docName}")
	public void deleteMetadatInfo(@PathVariable("docId") String docId){
		try{
			logger.trace("delete function called");
		metadataService.deleteMetadatInfo(docId);
		}catch (Exception e){
			logger.error("error while deletedocument call "+e);
		}
	}

	@PutMapping(value = "/info")
	public void updateMetadatInfo(@RequestBody MetaDataInfo metadataInfo){
		try{
			logger.trace("update function called");
		metadataService.updateMetadatInfo(metadataInfo);
		}catch (Exception e){
			logger.error("error while updatedocument call "+e);
		}
	}

	@GetMapping(value = "/list-movies")
	public List<MetaDataInfo> getAllMetadataInfos(){
		List<MetaDataInfo> list = new ArrayList<>();
		try{
			logger.trace("getAll function called");
		list = metadataService.getAllMetadataInfos();
		}catch (Exception e){
			logger.error("error while getAlldocument call "+e);
		}
		return list;
	}


}
