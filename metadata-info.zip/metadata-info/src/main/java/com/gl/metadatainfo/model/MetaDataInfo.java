package com.gl.metadatainfo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Metadatainfo")
public class MetaDataInfo {

	@Column(name = "docid")
	@Id
	private String docId;

	@Column(name = "doctype")
	private String docType;

	@Column(name = "docsize")
	private String docSize;

	public MetaDataInfo() {
	}

	public MetaDataInfo(String docId, String docType, String docSize) {
		this.docId = docId;
		this.docType = docType;
		this.docSize = docSize;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getDocSize() {
		return docSize;
	}

	public void setDocSize(String docSize) {
		this.docSize = docSize;
	}

}
