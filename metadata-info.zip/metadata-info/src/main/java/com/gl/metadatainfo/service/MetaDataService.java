package com.gl.metadatainfo.service;

import com.gl.metadatainfo.dao.MetaDataDAO;
import com.gl.metadatainfo.model.MetaDataInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MetaDataService {

	 @Autowired
	 MetaDataDAO metadataDAO;

	  public MetaDataInfo getMetadataInfo(String docId) {
		  MetaDataInfo metadataInfo = metadataDAO.getMetadataInfo(docId);
	      System.out.println("get bhawna service " +metadataInfo.getDocId());
	      return metadataInfo;
	  }

	  public List<MetaDataInfo> getAllMetadataInfos() {
	    List<MetaDataInfo> list = metadataDAO.getAllMetadataInfos();
	    return list;
	  }

	  public void addMetadataInfo(MetaDataInfo metadataInfo) {
		  metadataDAO.addMetadataInfo(metadataInfo);
	  }

	  public void updateMetadatInfo(MetaDataInfo metadataInfo) {
		  metadataDAO.updateMetadatInfo(metadataInfo);
	  }

	  public void deleteMetadatInfo(String docId) {
		  metadataDAO.deleteMetadatInfo(docId);
	  }


}
