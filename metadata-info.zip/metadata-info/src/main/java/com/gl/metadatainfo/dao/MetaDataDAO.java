package com.gl.metadatainfo.dao;

import com.gl.metadatainfo.model.MetaDataInfo;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
@EnableJpaRepositories
public class MetaDataDAO {

	private static final Logger logger = LogManager.getLogger(MetaDataDAO.class);
	@Autowired
	  protected SessionFactory sessionFactory;

	  
	  public void exit() {
	    sessionFactory.close();
	  }
	  
	  public void closeFactory() {
		    if (sessionFactory != null) {
		        try {
		            sessionFactory.close();
		        } catch (HibernateException ignored) {
		        	logger.error("Couldn't close SessionFactory", ignored);
		        }
		    }
	  }

	  public List<MetaDataInfo> getAllMetadataInfos() {
	    Session session = sessionFactory.openSession();
	    List<MetaDataInfo> list = new ArrayList<>();
	    try {
	    	list = session.createQuery("from MetaDataInfo").getResultList();
	    }
	    catch (Exception e) {
	        logger.error(e);
	      }
	      finally {
	          if (session != null) {
	              session.close();
	          }
	      }
	    return list;
	  }

	  public MetaDataInfo getMetadataInfo(String docId) {
		  MetaDataInfo metadata = new MetaDataInfo() {
		};
	    Session session = sessionFactory.openSession();
	    try {
	    	metadata = session.get(MetaDataInfo.class, docId);
		    System.out.println("in metainfo dao   "+metadata.getDocId());
	      logger.info(metadata);
	    } catch (Exception e) {
	      logger.error(e);
	    }
	    finally {
	        if (session != null) {
	            session.close();
	        }
	    }
	    return metadata;
	  }

	  public void addMetadataInfo(MetaDataInfo metadataInfo) {
	    Session session = sessionFactory.openSession();
	    try {
	      session.beginTransaction();
	      String id = (String) session.save(metadataInfo);
	      System.out.print("id is "+id);
	      session.getTransaction().commit();
	    } catch (Exception e) {
	      logger.error(e);
	    }
	    finally {
	        if (session != null) {
	            session.close();
	        }
	    }
	  }

	  public void updateMetadatInfo(MetaDataInfo metadataInfo) {
	    Session session = sessionFactory.openSession();
	    try {
	      session.beginTransaction();
	      session.update(metadataInfo);
	      session.getTransaction().commit();
	    } catch (Exception e) {
	      logger.error(e);
	    }
	    finally {
	        if (session != null) {
	            session.close();
	        }
	    }
	  }

	  public void deleteMetadatInfo(String docId) {
	    Session session = sessionFactory.openSession();
	    try {
	      session.beginTransaction();
	      session.delete(getMetadataInfo(docId));
	      session.getTransaction().commit();
	    } catch (Exception e) {
	      logger.error(e);
	    }
	    finally {
	        if (session != null) {
	            session.close();
	        }
	    }
	  }


	  

}
